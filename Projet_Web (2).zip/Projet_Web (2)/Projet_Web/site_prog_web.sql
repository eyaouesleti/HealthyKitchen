-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 06 mai 2022 à 17:34
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";



--
-- Base de données : `site_prog_web`
--

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `id_commande` int(3) NOT NULL AUTO_INCREMENT,
  `pseudo` text,
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `email` text NOT NULL,
  `telephone` text,
  `ville` text NOT NULL,
  `adresse` text NOT NULL,
  `nom_recette` text NOT NULL,
  `quantite` int(11) NOT NULL,
  PRIMARY KEY (`id_commande`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_commande`, `pseudo`, `nom`, `prenom`, `email`, `telephone`, `ville`, `adresse`, `nom_recette`, `quantite`) VALUES
(1, 'Asma', 'Asma', 'chouaibi', 'chouaibiasma15@gmail.com', '', 'Tunis', 'qsdfvb', 'salade', 2),
(2, 'Asma', 'Asma', 'chouaibi', 'chouaibiasma15@gmail.com', '52599464', 'Tunis', 'sdfghjuik', 'makloub ', 1),
(3, 'asma', 'Asma', 'Chouaibi ', 'chouaibiasma15@gmail.com', '54126985', 'TUNIS', 'hgjgjh', 'tarte', 1);

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `id_client` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `telephone` text NOT NULL,
  `email` text NOT NULL,
  `ville` text NOT NULL,
  `sujet` text NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY (`id_client`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `contact`
--

INSERT INTO `contact` (`id_client`, `nom`, `prenom`, `telephone`, `email`, `ville`, `sujet`, `msg`) VALUES
(1, 'Asma', 'Chouaibi ', '54126985', 'chouaibiasma15@gmail.com', 'Tunis ', 'commande ', 'comment passer une commande '),
(2, 'Emna ', 'Chouaibi ', '54126985', 'emna@gmailcom', 'Tunis ', 'commande ', ' bonjour');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

DROP TABLE IF EXISTS `membre`;
CREATE TABLE IF NOT EXISTS `membre` (
  `id_membre` int(3) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(20) NOT NULL,
  `mdp` varchar(32) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `civilite` enum('m','f') NOT NULL,
  `ville` varchar(20) NOT NULL,
  `code_postal` int(5) UNSIGNED ZEROFILL NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `statut` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_membre`),
  UNIQUE KEY `pseudo` (`pseudo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `membre`
--

INSERT INTO `membre` (`id_membre`, `pseudo`, `mdp`, `nom`, `prenom`, `email`, `civilite`, `ville`, `code_postal`, `adresse`, `statut`) VALUES
(1, 'Asma', 'azerty123', 'Asma', 'chouaibi', 'hhh@gmail.com', 'f', 'Tunis', 50000, 'sxdcfvgbh', 0);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `id_produit` int(3) NOT NULL AUTO_INCREMENT,
  `categorie` varchar(20) NOT NULL,
  `nom_article` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `photo` text,
  `prix` int(3) NOT NULL,
  PRIMARY KEY (`id_produit`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id_produit`, `categorie`, `nom_article`, `description`, `photo`, `prix`) VALUES
(1, 'Salade ', 'Salade cesar sauce parmesan et nuggets', 'La sauce cesar\r\n65 ml creme de soja\r\n55 g parmesan\r\n35 g anchoiade\r\n7 ml jus de citron\r\nail\r\nLa panure des nuggets\r\n340 g filet de poulet\r\n100 g flocon d\'avoine\r\n3 g epices masala\r\n2 g sel\r\nla salade\r\nroquette\r\n150 g tomate cerise\r\n150 g concombre\r\n120 g avocat\r\n15 g amande', 'https://recettehealthy.com/wp-content/uploads/2020/06/salade-c%C3%A9sar-fromage.jpg.webp', 15),
(2, 'Salade', 'Salade de pates et legumes healthy', '75 g tomates cerises\r\n50 g pate a l\'epeautre\r\n50 g feta\r\n45 g poivron jaune\r\n35 g poivron rouge\r\n15 g jeunes pousses d\'epinard\r\n15 g oignon rouge\r\n3 g graines de sesame\r\n2 cerneaux noix de Grenoble\r\n3 g pignon de pin\r\nLa sauce\r\n10 ml vinaigre balsamique\r\n10 ml miel\r\n5 ml jus de citron\r\n1 g basilic', 'https://recettehealthy.com/wp-content/uploads/2017/06/salade-healthy-720x405.jpg.webp', 15),
(3, 'Recette Sallee ', '\r\nTarte aux tomates et oignon au chevre', 'La pate brisee\r\n235 g farine de ble T80\r\n1 oeuf\r\n65 ml eau tiede\r\n30 ml huile d\'olive\r\n1 pincee sel\r\nLa garniture de tomate\r\n250 g tomate noire de crimee\r\n230 g tomate ananas\r\n230 g tomate green zebra\r\n90 g tomate grappe\r\n70 g fromage de chevre frais\r\nLa garniture d\'oignon\r\n460 g oignon jaune\r\n50 ml vinaigre balsamique\r\n30 g sucre complet\r\nmiel', 'https://recettehealthy.com/wp-content/uploads/2020/06/tarte-tomate-chevre.jpg.webp', 30),
(4, 'Recette Sallee', 'Lasagne au chou-fleur vegetarienne', 'INGREDIENTS\r\n8 feuilles a lasagne\r\nLa bechamel maison\r\n1 L lait de soja\r\n100 g fecule de pommes de terre ou mais ou arrow root\r\n90 g mascarpone\r\n25 g bouillon de legume bio en poudre\r\nLes legumes\r\n900 g chou-fleur\r\n130 g champignon\r\nLes proteines de soja\r\n145 g oignon jaune\r\n100 g proteine de soja crue', 'https://recettehealthy.com/wp-content/uploads/2020/04/lasagne-legume-bechamel.jpg.webp', 25),
(5, 'Recette sucree', 'Brownie fondant sans gluten aux noisettes', '200 g chocolat noir\r\n3 oeufs\r\n150 g compote\r\n70 g noisette\r\n35 g lentille corail', 'https://recettehealthy.com/wp-content/uploads/2020/11/brownie-sans-gluten.jpg.webp', 12),
(6, 'Recette Sucree', 'Pancake sans beurre moelleux et fluffy', '110 g farine de ble\r\n90 g banane sans peau\r\n90 g yaourt nature\r\n1 gros oeuf de 60g\r\n15 g sucre complet\r\n5 g levure chimique\r\n2 g sel de Guerande', 'https://recettehealthy.com/wp-content/uploads/2019/08/pancake-moelleux.jpg.webp', 11),
(7, 'Boisson ', 'Milkshake mangue abricot sans lait', '350 g mangue\r\n230 g abricots\r\n210 ml lait d\'amande\r\n200 ml creme d\'amande\r\nLa decoration\r\nframboise\r\nfeuilles de menthe', 'https://recettehealthy.com/wp-content/uploads/2020/06/milkshake-mangue-abricot.jpg.webp', 15),
(8, 'Boisson', 'Smoothie vert : avocat ananas et epinard', '75 g avocat\r\n180 g ananas\r\n50 g epinard\r\n125 ml eau', 'https://recettehealthy.com/wp-content/uploads/2017/07/green-smoothie-448x720.jpg.webp', 8);
COMMIT;

