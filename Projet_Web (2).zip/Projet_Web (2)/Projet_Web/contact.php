<?php require_once("cxbd.php");
//--------------------------------- TRAITEMENTS PHP ---------------------------------//
if($_POST)
{
    //debug($_POST);

   
            executeRequete("INSERT INTO contact (nom, prenom,telephone,email, ville, sujet,msg) VALUES ('$_POST[nom]', '$_POST[prenom]', '$_POST[telephone]', '$_POST[email]','$_POST[ville]', '$_POST[sujet]','$_POST[msg]')");
            $contenu .= "<div class='validation'>Votre message a bien été enregistré <a href=\"index.php\"><u>Cliquez ici pour revenir à la page d'acceuil </u></a></div>";
    }


?>




<link rel="stylesheet" type="text/css" href="style1.css">
<?php require_once("index.php"); ?>
<body style=" background-image: url(img/fondcontactez_nous.jpg)">
<form method="post" action="">
	<table cellpadding=2; cellspacing="3"; >
		<caption>CONTACTEZ-NOUS</caption>
	<tr>
		<td><label for="nom">Nom</label></td> 
		<td><label for="prenom">Prénom</label></td>
	</tr>
     <tr>
     	<td><input type="text" name="nom" placeholder='nom' id='nom'/></td>
        <td><input type="text" name="prenom" placeholder='prenom' id='prenom'/></td>
	</tr>
	<tr>
		<td><label for="telephone">Téléphone</label></td> 
		<td><label for="email">E-mail</label></td>
    </tr>
    <tr>
    	  <td><input type="tel" name="telephone" placeholder='Téléphone' id='telephone'/></td>
          <td><input type="email" name="email" placeholder='email' id='email'/></td>
	</tr>
	<tr>
		<td><label for="ville">Ville</label></td> 
		<td><label for="sujet">Sujet</label></td>
	</tr>
     <tr>
     	<td><input type="text" name="ville" placeholder='ville' id='ville'/></td>
        <td><input type="text" name="sujet" placeholder='sujet' id='sujet'/></td>
	</tr>
      <tr>
      <td> <label for="Text">Votre message</label> </td> </tr>
	  </table>
	  <textarea class="t" name="msg" id="msg" rows="10" cols="50" placeholder='ecrivez votre message' id='msg'> </textarea>       
           

		    <input type="submit" name="passer" value="valider"style="margin-left: 70%"/>   
</form>
      	   

</body>
<?php require_once("indexbas.php"); ?>