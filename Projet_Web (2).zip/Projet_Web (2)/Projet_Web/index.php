
<!Doctype html>
<html>
    <head>
        <title>Healthy kitchen</title>
        <link rel="stylesheet" href="index.css">
    </head>
    <body>  
<header>
    <div class="en-tete"  >
	<div class="logo">
		<img src="img/logo.jpg" alt="logo"/>
	</div>
<div class="slogon">
	<div class="titredusite">Healthy kitchen</div>
	<div class="quote">Those who have no time for healthy eating will sooner or later have to find time for illness</div>
</div>

</div>



</div>

            <div class="conteneur">
                
                <nav>
                <ul>
		<li><a href="acceuil.php">Acceuil</a></li>
        <li> <a href="inscription.php">Inscription</a></li>
        <li>    <a href="connexion.php">Passer Commande </a></li>
        <li>  <a href="boutique.php">Recettes</a></li>
        <li>  <a href="contact.php">Contactez-nous</a></li>
                </nav>

            </div>
        </header>
        <section>
            <div class="conteneur">
  