<link rel="stylesheet" type="text/css" href="style1.css">

<?php require_once("cxbd.php");
//--------------------------------- TRAITEMENTS PHP ---------------------------------//
if($_POST)
{
    // $contenu .=  "pseudo : " . $_POST['pseudo'] . "<br>mdp : " .  $_POST['mdp'] . "";
    $resultat = executeRequete("SELECT * FROM membre WHERE pseudo='$_POST[pseudo]'");
    if($resultat->num_rows != 0)
    {
        // $contenu .=  '<div style="background:green">pseudo connu!</div>';
        $membre = $resultat->fetch_assoc();
        if($membre['mdp'] == $_POST['mdp'])
        {
            //$contenu .= '<div class="validation">mdp connu!</div>';
            foreach($membre as $indice => $element)
            {
                if($indice != 'mdp')
                {
                    $_SESSION['membre'][$indice] = $element;
                }
            }
            header("location:formulaire_commande.php");
        }
        else
        {
            $contenu .= '<div class="erreur">Erreur de MDP</div>';
        }       
    }
    else
    {
        $contenu .= '<div class="erreur">Erreur de pseudo</div>';
    }
}

?>
<?php require_once("index.php"); ?>
<body style=" background-image: url(img/fondcontactez_nous.jpg)">
<form method="post" action="">

<table cellpadding=2; cellspacing="3";> 

<tr>
    <td><label for="pseudo">Pseudo</label><br></td>
    <td> <input type="text" id="pseudo" name="pseudo"><br> <br></td>
</tr>

<tr>
<td><label for="mdp">Mot de passe</label><br></td>
   
    <td><input type="text" id="mdp" name="mdp"><br><br></td>

</tr>

<tr>
    <td><input type="submit" value="Se connecter"></td>
</tr>



</table>
</form>
</body>
<?php require_once("indexbas.php"); ?>