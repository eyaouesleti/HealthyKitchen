<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="style.css">
<title>accueil </title>
</head>


<body>

<?php require_once("index.php"); ?>



<aside><img src="img/image.jpg" alt="logo"/><p>Une bonne alimentation fournit à l'organisme les nutriments essentiels : fluide, acides aminés essentiels des protéines2, acides gras, vitamines, minéraux, et suffisamment de calories. Une alimentation saine peut être satisfaite par une variété d'aliments d'origine végétale ou animale.Pour cela nous proposons quelque recette healthy.</p></aside>

<section>
	<article>
		<h2>L'importance d'une alimantation saine</h2>
	<p>
	Une bonne alimentation joue un rôle essentiel sur notre santé. Elle diminue le risque de développer certaines maladies chroniques et augmente ainsi l’espérance de vie. En effet, les aliments apportent l’énergie nécessaire au bon fonctionnement de nos cellules et permettent le développement harmonieux de notre corps. C’est pourquoi il est essentiel de surveiller ce que l’on mange, tant en termes de qualité que de quantité. </p></article>
	<article>
		<h2> Des règles à connaître pour manger healthy</h2>
		<ol>
    	<li>Boire suffisamment d'eau</li>
		<li>Pensez aux bonnes graisses</li>
		<li>Mangez des fruits et des légumes</li>
		<li>Manger un petit déjeuner équilibré</li>
		<li>Limitez les sucres industriels</li>
		<li>Mangez des aliments variés</li>
		</ol>
	</article>
</section>
<?php require_once("indexbas.php"); ?>
</body>

</html>