<?php
require_once("cxbd.php");
//--------------------------------- TRAITEMENTS PHP ---------------------------------//
if(isset($_GET['id_produit']))  { $resultat = executeRequete("SELECT * FROM produit WHERE id_produit = '$_GET[id_produit]'"); }
if($resultat->num_rows <= 0) { header("location:boutique.php"); exit(); }
 
$produit = $resultat->fetch_assoc();
$contenu .= '<div class="fiche-produit">';
$contenu .= "<h2>Recette : $produit[nom_article]</h2><hr><br>";
$contenu .= "<img src='$produit[photo]' ='150' height='150'>";
$contenu .= "<p><i>Description: $produit[description]</i></p><br>";
$contenu .= "<p>Prix : $produit[prix] DT</p><br>";
 
$contenu .= "<br><a href='boutique.php?categorie=" . $produit['categorie'] . "'>Retour vers la séléction de " . $produit['categorie'] . "</a>";
//--------------------------------- AFFICHAGE HTML ---------------------------------//
require_once("index.php");
echo $contenu;
require_once("indexbas.php"); ?> 
<body style=" background-image: url(img/fondacceuil.jpg);background-repeat: no-repeat; background-size: cover;">
</body>

<link rel="stylesheet" href="boutique.css">
<link rel="stylesheet" href="fiche.css">