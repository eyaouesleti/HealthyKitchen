<link rel="stylesheet" type="text/css" href="style1.css">
<?php require_once("cxbd.php");
//--------------------------------- TRAITEMENTS PHP ---------------------------------//
if($_POST)
{
    debug($_POST);

   
            executeRequete("INSERT INTO commande (pseudo, nom, prenom, email,telephone, ville, adresse,nom_recette,quantite) VALUES ('$_POST[pseudo]', '$_POST[nom]', '$_POST[prenom]', '$_POST[email]','$_POST[telephone]', '$_POST[ville]', '$_POST[adresse]','$_POST[prod]','$_POST[qt]')");
            $contenu .= "<div class='validation'>Votre commande a bien été enregistré <a href=\"index.php\"><u>Cliquez ici pour revenir à la page d'acceuil </u></a></div>";
    }


?>
<?php require_once("index.php"); ?>
<body style=" background-image: url(img/fondcontactez_nous.jpg)">
<form method="post" action="">
    <table cellpadding=2; cellspacing="3">


   <tr>
<td><label for="pseudo">Pseudo</label><br>
</td> 
<td> <label for="nom">Nom</label><br>
</td> 
</tr> 


<tr>
      <td><input type="text" id="pseudo" name="pseudo" maxlength="20" placeholder="votre pseudo" pattern="[a-zA-Z0-9-_.]{1,20}" title="caractères acceptés : a-zA-Z0-9-_." required="required"><br><br>
</td>
<td><input type="text" id="nom" name="nom" placeholder="votre nom"><br><br>
</td>  
</tr> 


<tr>
      <td><label for="prenom">Prénom</label><br>
</td> 
<td><label for="email">Email</label><br>
</td> 
</tr> 



<tr>
      <td><input type="text" id="prenom" name="prenom" placeholder="votre prénom"><br><br>
</td> 
<td><input type="email" id="email" name="email" placeholder="exemple@gmail.com"><br><br>
</td> 
</tr> 



<tr>
      <td><label for="telephone">Téléphone</label><br>
</td> 
<td><label for="ville">Ville</label><br>
</td>
</tr> 


<tr>
      <td><input type="tel" id="telephone" name="telephone" placeholder="votre numéro de télephone"><br><br>
</td> 
<td><input type="text" id="ville" name="ville" placeholder="votre ville" pattern="[a-zA-Z0-9-_.]{5,15}" title="caractères acceptés : a-zA-Z0-9-_."><br><br>
</td> 
</tr> 



<tr>
      <td><label for="adresse">Adresse</label><br>
</td> 
<td><label for="prod">Nom recette</label><br>
</td> 
</tr> 


<tr>
      <td><textarea id="adresse" name="adresse" placeholder="votre dresse" pattern="[a-zA-Z0-9-_.]{5,15}" title="caractères acceptés :  a-zA-Z0-9-_."></textarea><br><br>
</td> 
<td><input type="text" id="prod" name="prod" placeholder="votre choix"><br><br>
</td> 
</tr> 


<tr>
<td> 
<label for="qt">Quantité</label><br>
</td> 
</tr>

<tr>
<td> 
<input type="number" id="qt" name="qt" placeholder="la quantité " min='1'><br><br>
</td> 
</tr>
  

<tr>
<td> 
<input type="submit" name="passer" value="Valider">
</td> 
</tr>
    <table>
</form>
</body>
<div class="f"><?php require_once("indexbas.php"); ?></div>