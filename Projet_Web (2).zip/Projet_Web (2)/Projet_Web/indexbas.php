</div>
        </section>
        <footer>
            <div class="conteneur">    
                <?php echo date('Y'); ?> - Tous droits reservés - Healthy Kitchen.
            </div>
        </footer>
    </body>
</html>